// rle decode
void decode_rle(unsigned char* input,unsigned char* output)
{
	int len;
	int pos=0;
    int ch, i;

	len=*(int*)input;
	pos+=4;
	
    while (1)
       {
       ch=*(input+pos);
	   pos++;
       if (pos>len)
           break;
       if (ch > 127)
          {
          i = ch - 127;   /* i is the number of repetitions */
          /* get the byte to be repeated */
		   ch=*(input+pos);
		   pos++;
          /* uncompress a chunk */
          for ( ; i ; i--)
		  {
			   *output=ch;
			   output++;
          }
	   }
       else
          {
          /* copy out some uncompressed bytes */
          i = ch + 1;     /* i is the no. of bytes */
          /* uncompress a chunk */
          for ( ; i ; i--)
             {
			   ch=*(input+pos);
			   pos++;
			   *output=ch;
			   output++;
             }
          }
      } /* end while */
}
