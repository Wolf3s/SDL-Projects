void Expand(long *input, char *output);
