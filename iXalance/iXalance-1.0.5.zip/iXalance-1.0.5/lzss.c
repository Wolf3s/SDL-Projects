#include <stdio.h>

#define INDEX_BIT_COUNT      10     // This is a total window of 4Kb
#define LENGTH_BIT_COUNT     4
#define WINDOW_SIZE          ( 1 << INDEX_BIT_COUNT )
#define BREAK_EVEN           ( ( 1 + INDEX_BIT_COUNT + LENGTH_BIT_COUNT ) / 9 )
#define RAW_LOOK_AHEAD_SIZE  ( 1 << LENGTH_BIT_COUNT )
#define LOOK_AHEAD_SIZE      ( RAW_LOOK_AHEAD_SIZE + BREAK_EVEN )
#define END_OF_STREAM        0

/*
 * Function prototypes for ANSI C compilers
 */
char swindow[1024];
void Expand (long *input, char *output);
void InitBitstring (long *bitstring);
int InputBit();
unsigned long InputBits(int bit_count);

// read one bit out of the bitstream


#define InputBit(value)												\
{                                                                   \
    if (Bitstring_Count == 0)                                       \
    {                                                               \
		Bitstring_Rack = *Bitstring++;                              \
    	Bitstring_Count = 31;                                       \
	}                                                               \
	else                                       						\
		Bitstring_Count--;                                          \
																	\
	value = (Bitstring_Rack>>31);                                   \
    Bitstring_Rack <<= 1;                                           \
																	\
}

// read a bitstring out of the bitstream

#define InputBits(bit_count,return_value)							\
{                                                                   \
                 													\
	if (Bitstring_Count < bit_count)                                \
	{                                                               \
		long second_pass = bit_count-Bitstring_Count;               \
																	\
		return_value = Bitstring_Rack >> (32-bit_count);            \
		Bitstring_Rack = *Bitstring++;                              \
		return_value |= Bitstring_Rack >> (32-second_pass);         \
		Bitstring_Rack <<= second_pass;                             \
		Bitstring_Count = 32-second_pass;                           \
	}                                                               \
	else                                                            \
	{                                                               \
		return_value = Bitstring_Rack >> (32-bit_count);            \
		Bitstring_Count -= bit_count;                               \
		Bitstring_Rack <<= bit_count;                               \
	}                                                               \
}


/*
 * This is the expansion routine for the LZSS algorithm.  All it has
 * to do is read in flag bits, decide whether to read in a character or
 * a index/length pair, and take the appropriate action.
 */

void Expand(long *Bitstring, char *output)
{
	int window_ptr, window_ptr2;
    int i;
	int c;
	unsigned long Bitstring_Count = 0;
	unsigned long Bitstring_Rack;
	int match_length;
	int match_position;
	
    window_ptr=1;

	while (1)
    {
 		InputBit(i);
		if (i)
        {
            InputBits(8,c);

            *output++ = c;
            swindow[window_ptr]= c;
			
			window_ptr++;
			window_ptr&=1023;
        }

        else
        {
			InputBits(INDEX_BIT_COUNT,match_position);
            if ( match_position == END_OF_STREAM )
				break;

            InputBits(LENGTH_BIT_COUNT,match_length);
            match_length += BREAK_EVEN;

			window_ptr2 = match_position;

			for (i=0;i<=match_length;i++ )
            {
				c = swindow[window_ptr2++];
				window_ptr2&=1023;
	            swindow[window_ptr++]= c;
                *output=c;
				output++;
				window_ptr&=1023;
			}
        }
    }
}






