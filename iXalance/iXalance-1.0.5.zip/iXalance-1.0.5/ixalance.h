// This structure needs to be 100% the same as this one. The demos rely on it.
// Most of the data doesn't really have to be filled in though.
#pragma pack(1)
typedef struct 
{
    unsigned char curmode;
    unsigned char tempstat;
    unsigned char forcebuf;
    unsigned char forcevr;
	
    void* tclfb;
    void* htclfb;
    void* gfxlfb;
    unsigned int xres;
    unsigned int yres;
    unsigned int gfxscanlen;
    unsigned int gfxbanksize;
    unsigned short int gfxmode;

    unsigned int tcscanlen;
    unsigned int tcxres;
    unsigned int tcyres;
    unsigned int tcbanksize;
    unsigned short int tcmode;
    unsigned char tcbitmode;
    unsigned char rcomp;
    unsigned char gcomp;
    unsigned char bcomp;
    unsigned char rmask;
    unsigned char gmask;
    unsigned char bmask;
    unsigned char tcstatus;
    unsigned int htcscanlen;
    unsigned int htcbanksize;
    unsigned short int htcmode;
    unsigned char htcbitmode;
    unsigned char hrcomp;
    unsigned char hgcomp;
    unsigned char hbcomp;
    unsigned char hrmask;
    unsigned char hgmask;
    unsigned char hbmask;
    unsigned int panproc;
    unsigned int bankproc;
    unsigned int vgaofs;
    unsigned int convtab;
    unsigned int reallfb;
    unsigned int dummyadd;
} Tgfxmodeinfo;
#pragma pack()

#ifdef __cplusplus
extern "C" {
#endif
extern Tgfxmodeinfo gfxmodeinfo;
#ifdef __cplusplus
};
#endif

#ifdef __cplusplus
extern "C" {
#endif
//---------------------------------------------------------------------------
// iXalance driver externals.
// All this stuff is in my win32.cpp, and would be in your linux.cpp 
// or whatever.

// Set a specific screenmode. This should never fail. If the mode isn't 
// available, fake it. 
int IXDRV_SetVideoResolution(int x,int y,int depth);
// Gets value of a 1000hz timer
int IXDRV_GetTime();

// Allocate memory. Memory should be readable/writable/executable
void* IXDRV_Malloc(int);

// Guess what, frees memory.
int IXDRV_Free(void*);

// Allocates memory for the current mode. Fills in the gfxmodeinfo stuff.
// (only bitcomponent info + tclfb pointer)
// Btw, NEVER provide a pointer to actual videomemory, always use a buffer
// (It should work, but it will be shitslow because of vidmem reads.)
void IXDRV_InitScreen();

// Makes the current fake 'lfb' visible. In other words, copy all the shit
// to vidmem. If possible uses pageflipping and all that.
void IXDRV_CopyScreen();

// This function is called as often as reasonably possible, use it to
// check for messages and other housekeeping stuff.
void IXDRV_CheckMessages();

// Initialise graphics system for the first time. 
void IXDRV_InitGfx();
void IXDRV_QuitGfx();

// Output debug info. Put it in a file or something. Or just ignore it :)
void IXDRV_OutputDebug(const char *fmt, ...);


//---------------------------------------------------------------------------
// Stuff so the system can initialise the sound, which should actually be
// in a seperate module, but which is in D32LOAD at the moment.
void IXSND_SoundSetup();
void IXSND_SoundInit();

//---------------------------------------------------------------------------
// Callbacks for the driver to user (D32LOAD)

// That's where we start
void DemoMain();

// Is called when the app is being terminated.
void BreakPart();

// Is called when the driver wants the demo to pause.
// The Timer value returned by IXDRV_GetTime is automatically being stopped,
// but for instance music should be stopped as well. 
void PausePart();
void ResumePart();

#ifdef __cplusplus
}
#endif

    
// Uhm. Used to pass the name of the demo and the name of the .IXA file to
// execute between the two modules
#ifdef __cplusplus
extern "C" {
#endif.
extern char IXA_Filename[256];
extern char IXA_Name[256];
#ifdef __cplusplus
};
#endif
