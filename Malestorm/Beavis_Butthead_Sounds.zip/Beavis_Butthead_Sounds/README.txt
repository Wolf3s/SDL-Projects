BEAVIS & BUTTHEAD MAELSTROM SOUND MADNESS 1.0.1

Ok, somebody had to do it.  Why me, I don't know.  But it's done and it's yours.  Enjoy.  If you run into memory problems, do the "Get Info" thing and increase your preferred size to at least 3000K.  That should be plenty.

As far as the sounds are concerned, you guys can thank Lewis Francis for doing all of the hard work.  Thanks, Lewis!  I got all the sounds from his "Beavistack 1.01", downsampled them to 11kHz, then went to ResEdit for the snd resource swap and hours later, voila, Beavis & Butthead Maelstrom Sound Madness 1.0.1 was born.  

While figuring out which sounds to swap for which, I tried to imagine Beavis & Butthead sitting at Stuart's house playing Maelstrom laughing as they played the game for the first time.  See what you think.

Unfortunately, I don't know what the legal repercussions of this will be so I've probably said too much already.  All you need to know is that the characters "Beavis & Butthead" as well as the Beavis & Butthead sounds used in this file belong to Se�or Mike Judge and the heavies at MTV.  I got so caught up in this thing that I probably went and used all this stuff w/o permission.  Ooooops.  Oh well, I guess the only thing I can do for now is coin another ware-ism:  Beavis&ButtheadWare. 

This sound file is also Beavis&ButtheadWare.  If you use it, tune into MTV, watch Beavis & Butthead daily, and buy the advertisers stuff!!!   

Comments?  Suggestions?  Send 'em to:

Gatorader@aol.com

'Nuf said.  Time for bed.  Have a good one.
