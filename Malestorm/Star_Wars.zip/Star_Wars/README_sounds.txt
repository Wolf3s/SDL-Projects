         Star Wars Maelstrom Sounds

 To start off, thanks for downloading this.  But NOTE: These sounds are NOT taken from the actual movie versions of Star Wars!  They are from the two tape series made of Star Wars and The Empire Strikes Back!  Actually, there's not much of a difference, but just in case you cared.  If you didn't know about the Star Wars audio series, it was on National Public Brodcasting a looooong time ago and was so popular they made tape and CD sets for it!  It included the voices of Mark Hamill (Luke) and Antony Daniels (C-3PO).  (Don't ask me why they never made a Return of the Jedi radio series; I mean, it's not like the first two weren't popular enough!)

	Anyway, make sure that these sounds are in the same folder as Maelstrom and also make sure to pump up the memory on Maelstrom.  These sounds take up more memory than normal, so just set the allocated memory higher.  I'm in the process of making other sound files for Maelstrom, some of which I won't be able to upload 'cause of contract violations or something.  In the next few months, I should finish putting together another SW sound file, along with Star Trek:TNG, DS9, or Voyager sounds (I wonder just how annoying Janeway's voice can be?).  And maybe some MST3K sounds too...  Hope you enjoy the sounds!

	If you want to contact me and tell me how bad this sucked, how wonderful it was, etc...then drop me a message and I promise I'll get back to you (I've got nothing better to do)!!!!!!!

Sound List

Photon Shot - blaster
Multiplier Appears - Han yelling, "Haho, my day's complete!"
Explosion - blaster hitting something
Ship Explosion - Obi-Wan saying, "By striking me down, you have made me more powerful than you could possibly imagine..."
Boom2 - Vader breathing out
Boom1 - Vader breathing in
Missed Multiplier - Yoda saying, "Control!  You must lean control!!!"
Multiplier Shot - Yoda saying, "Use the Force, young Skywalker!"
Steel - Chewie roaring
Bonk - quick Star Wars beep
Star Wars Riff - theme music
Prize Appears - Han saying, "Oh, it's funny how this stuff brightens your day, isn't it?"
Got Canister - C-3PO saying, "I liked you from the very first!"
Game Over - Vader saying, "All too easy, son of Skywalker.  Perhaps you are not as strong as the Emporer thought you to be..."
New Life - Obi-Wan saying, "Use the Force, Luke."
Comet Appears - Obi-Wan saying, "I'd forgotten how important that is to you."
Got Comet - Luke saying, "Thanks!"
No Bonus - Grand Moff Tarkin saying, "I think you overestimate these Rebels' chances."
Vortex Appears - Luke screaming, "Nooooooooooo hooooh hoh"
Mine Appears - Leia saying, "Well, look what slithered in."
Shield On - door opening
No Shield - Luke saying, "Hang on, Artoo!"
Nova Appears - Han asking, "What's eating you?"
Nova Boom - Han saying, "Why don't you buckle in and give it a rest!"
Got Lucky - Han saying, "What'd I tell you about luck, kid?"
Damaged Appears - Luke saying, "I'm hit!  I'm going down!"
Save Damaged - Han saying, "Thank you very, very much!"
Funk - R2-D2 beep
Enemy Appears - Han saying, "I think we're in trouble..."
Pretty Good - Vader saying, "Impressive!  Most impressive!"
Jets - M. Falcon's jets
Enemy Fire - X-wing blowing up (makes a good firing sound, though...)
Freeze - Vader ordering, "Commense the freezing cycle!"
Idiot - C-3PO yelling, "You stupid furball!"
Pause - Han saying, "Uhhh...excuse me, princess.  You've decided to put the Rebellion on hold, is that it?"

																																																										-Snorfle
