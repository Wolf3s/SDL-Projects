
I created these sounds for Andrew Welch's Maelstrom 1.4.2 because I saw something lacking in the list of available alternative sounds for the game.  With "The Simpsons" and "Blazing Saddles" sounds out there how could someone overlook the Stooges?

Sounds list:

Multiplier Shot - Curly "I'll make a note of it."
New Life - Larry "It's boiling."  Curly "It must be done."
No Shield - Curly "Soytenly."
Nova Appears - Curly "nyrrmh"
Saved Damaged - Curly "Can I help you?"
Idiot - Moe "This is all your fault, you!"
Ship Explosion - "(bonk) oh!!"
Game Over - "Three Stooges end theme"
Got Canister - Curly "woob woob woob woob"
Comet Appears - Curly "hey!"
Got Comet - Moe "Oh boy! Success!"
Mine Appears - Curly "Oh, stubborn eh!"
Vortex Appears - Curly "Seein' as there's no place around the place, I reckon this must be the place I reckon."
Missed Multiplier - Curly "nyahahah"
Got Lucky - Moe "Oh boy! Success!"
Damaged Appears - Curly "ohh! Look!"
Enemy Appears - Curly "Bring me back a piece of burnt toast and a rotten egg."
Funk - Curly "Why you!"
Multiplier Appears - Curly "Oh, a wise guy!"
Freeze - Moe "Come on, use your head!"
Pause - Moe "We ain't gettin' nowhere fast."
Prize Appears - Curly "Oh, I see."
Level Riff - "3 hellos"
Hot Damn - Curly "Soytenly"
Asleep At The Wheel - Moe "Wake up and go to sleep!"


I apologize to Larry for not including him more.

Robert Coldwell
ss07605@fa.geidai.ac.jp

