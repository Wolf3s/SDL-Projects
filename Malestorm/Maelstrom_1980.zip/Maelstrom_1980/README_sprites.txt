Here are some sprites I made using ResEdit and Adobe Photoshop. These will take you back to the days when Maelstrom was the newest game at the arcade.

Send questions and/or comments to: Trashsurfr@aol.com

Thanks to Ambrosia for this timeless classic.
 
