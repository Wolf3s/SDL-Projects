Here are some sounds I made using Sound Edit 16. These will take you back to the days when Maelstrom was the newest game at the arcade.

Send questions and/or comments to: Trashsurfr@aol.com

Thanks to Ambrosia for this timeless classic.

