Army of Darknes Maelstrom Sounds!!!

WELCOME TO THE ULTIMATE EXPERIENCE!

  Just about all of us have checked out Mr. Welch's awesome game! With parts of the game set up into modules, it is easy to make additions. I've had several requests for an Army of Darkness sound file, so here ya' go!

WHY YOU MUST DOWNLOAD!! :
* Sounds sampled directly from audio track
   (all were recorded by me)
* Excellent quality, unlike another file with some very similar sounds ...
* EVERY sound except for Jets, Enemy Fire, and the Explosion have been replaced with something new and different!!!
*How else can you hear Ash taunting the enemies in the Maelstrom??!
  Asteroids beat replaced with Aerosmith!
  Hear Ash scream as your ship blows to pieces; hear him tell you to "come get some"!

	If you don't have the game, you still might want to consider downloading this if only to receive lots of sounds that I have sampled into the file, including Army of Darkness, Steve Miller, Metallica, and Faith No More � to name a few. Use SoundExtractor or ResEdit to steal them from the resource fork.

REPLACEMENTS:
Bonk - drum beat from Metallica
Boom1 & Boom2 - remember the beginning of Aerosmith's "Rag Doll" ?
Comet Appears - Steve Miller riff
Damaged Appears - crying baby
Enemy Appears - I've got a bone to pick with you!
Freeze - Hail to the king, baby!
Funk - Metallica riff
Game Over - Run home and cry to mama!
Got Canister - Come get some...
Got Comet - Steve Miller "Some people call me the space cowboy"
Got Lucky - U2 Mysterious Mays riff
Pretty Good -> Hello Mr.Fancy Pants
MetallicaRiff replaces JimiRiff
Mine Appears - You shall diiiiie!!!
Missed Multiplier - Damn it!
Multiplier Appears - Who the hell are you?
Multiplier Shot - Name's Ash, <cocks gun>, housewares
New Life - riff from Faith No More's "Underwater Love"
No Bonus - moaning thing from Evil Dead
No Shield - Don't touch that please!
Nova Appears - Buckle up, bonehead!
Nova Boom - much better explosion with an echo
Pause - Bahm! Bahm!
Photon Shot - sounds like a shotgun
Prize Appears - Heeey baaaby!
Saved Damaged - Groovy!
Shield On - Bad Company clip
Ship Explosion - Ash cries out in pain
Shot Canister - You stupid idiot! (T-6500)
Steel - Hey! (Beetlejuice)
Vortex Appears - I'll swallow your soul!
Enemy Fire - SAME
Explosion - SAME
Jets - SAME

Christopher Scharver
AOL: Scharver
Internet: scharver@aol.com
