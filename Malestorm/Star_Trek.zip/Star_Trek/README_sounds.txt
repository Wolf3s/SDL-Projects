������������������������Trek Maelstom Sounds������������������������

Finally, some Trek Maelstrom Sounds.

The file "Trek Maelstrom Sounds" that comes with this Read Me file is intended to replace the "Maelstrom Sounds" file in the game Maelstrom.  It contains sounds from both the old series and Next Generation.  These sounds are great on a Hi-Fi since they involve some rather serious explosions etc.

Credits
Samples have been taken from various episodes of Star Trek: The Next Generation, Star Trek (The Old Series) and Star Trek: Voyager.  Star Trek, Star Trek: The Next Generation, Star Trek: Deep Space Nine and Star Trek: Voyager are trademarks of Paramount Communications.

Maelstrom (a very cool game) is Copyright 1992-6 by Ambrosia Software, Inc.

About Me
My homepage can probably be found at:
				http://www.usyd.edu.au/~astevent/
It has a stack of JPEGs from Trek and about 8 megs of Trek sounds, mostly sampled at 22KHz and generally very nice.

If you want to contact me for some reason:
				astevent@extro.ucc.su.oz.au

Look for my Trek Maelstrom Sprites, too.

Angus Steventon 1996
