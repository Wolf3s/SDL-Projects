#ifndef __BUTTONS_H__
#define __BUTTONS_H__

// this is class for the control with 'smiley' face on it
// the image is
// it invoke the onClick() methoid of the current sdlApp
class BMPButton : public CScreenControl
{
public:
	// state (image to display)
	int state;
	// pointer to image of the button
	CBMPFile* pImage; 
	// constructor
	BMPButton(int x, int y, int w, int h):CScreenControl(x,y,w,h)
	{
		state = 0; // up image
		pImage = NULL;
	}
	// hittest handler
	virtual int hittest(int x, int y);
	// paint handler
	virtual void repaint();
	// various mouse event handlers
	virtual void onLButtonDown(int x, int y, unsigned char flags);
	virtual void onLButtonUp(int x, int y, unsigned char flags);
	virtual void onMouseMove(int x, int y, unsigned char flags);
};

// the static control s on the two edges of the screen with 3 digits to display
//
class BMPCounterButton : public CScreenControl
{
public:
	// the number to display
	int number;
	// pointer to the image file with the digits in it
	CBMPFile* pImage; 
	// constructor
	BMPCounterButton(int x, int y, int w, int h):CScreenControl(x,y,w,h)
	{
		number = 0; // show zero by default
		pImage = NULL;
	}
	// hitest and paint routines
	virtual int hittest(int x, int y);
	virtual void repaint();
};

#endif //__BUTTONS_H__