SDL minesweeper

1. compiling the game
Please download the SDL developer kit in order to compile the project.
also note that the code is compiled with the Microsift compiler and thus it is 
dependant (in the struct alignment about bitmap headers)
So i order to run properly when it is compiled on other systems, enshure the proper struct members alignment to 1 or 2 bytes boundary so the headera to be read correctly from the disk.
Another issue that can make the code unportable are the poiter-to-member-functions used to route the events. Cjeck the compiler options to enable proper interpretation.

SDL development:
http://www.libsdl.org/download-1.2.html

Also put the 3 bitmap files and the SDL.DLL in the same folder as the executable :-)
or make sure that SDL.DLL is somewhere in the path so it can be found at runtime by the system loader.

2.  Playing the game
2.1 Keyboard

ESC 	- quit the Game
F2	- new Game

2.2. Mouse usage

Left button down + up - select and reveal the mine location
if there was a mine under it the game is over
if there is a number - it diplays the total number of mines that surround that location

Right button down - mark the location or if it was previously marked place the question mark over is or if it was with quastion mark remove it.

Both mouse buttons - select a location to be revealed around. if that locatioan was revealed and around it there are exactly the same number of marks as the number shown on thet location - it reveals the area. if there was a wrong mark over the location that dont have an mine under it and the game try to reveal the mine the game is over.

click on th esmile face to begin new game\

HAVE a FUN!
Damyan Ognyanoff 
e-mail:damyan@rocketmail.com
------------ event handling ---------

1. processing grammar for minesweeper

2. observable events
{ LbDown, RbDown, LbUp, RbUp, MMove }

2a. observable places
{ overUNV, over?, overMark, overREV}

3. takenActions

{ }

4.states table
{ sWait, sLBd, sRbD, sLbRbD, sLbRbDOnlyRight, sLbRbDOnlyLeft}

transitions
sWait(LbDown)-> sLbD
	overUNV -> viewASEmpty
	over?	-> viewASDown?
	overMark-> doNotChange
	overREV -> doNotChange
sWait(RbDown)-> sRbD
	overUNV -> viewASMark
	overMark-> viewASUp?
	over?	-> overUNV
	overREV -> ignore
sWAit(MMove)->	-> noAction
sWAit(LbUp)->	-> noAction
sWAit(RbUp)->	-> noAction

sLbD(LbDown)->	-> noAction
sLbD(RbDown)->sLbRbD -> cancel querySingle, unmark qurent, queryMultiple()
sLbD(MMove)->
	oldWas:
		overUNV -> viewASUNV
		over?	-> viewASUp?
		overMark-> doNotChange
		overREV -> doNotChange
	newIs:
	overUNV -> viewASEmpty
	over?	-> viewASDown?
	overMark-> doNotChange
	overREV -> doNotChange

sLbD(LbUp)->sWait	-> reveal
	nowhere	->ignore
	overUNV	-> reveal()
	over?	-> reveal()
	overMark-> ignore
	overREV -> ignore
sLbD(RbUp)->	-> noAction

sRbD(LbDown)->sLbRbD
	for_each_around(as is now)
sRbD(RbDown)->	-> noAction
sRbD(MMove)		-> noAction
sRbD(LbUp)->	-> noAction
sRbD(RbUp)->sWait	-> noAction

sLbRbD(LbDown)->	-> NoAction
sLbRbD(RbDown)->	-> NoAction
sLbRbD(MMove)->
	for_each_around(as was previous)
	for_each_around(as is now)
sLbRbD(LbUp)->sLbRbDOnlyRight
	for_each_around(as was previous)
	overUNV -> deactivate
	over?	-> deactivate
	overMark-> deactivate
	overREV ->
		if (nummarks == minefieldcount) 
			apply
		else 
			deactivate
sLbRbD(RbUp)->sLbRbDOnlyLeft->
	for_each_around(as was previous)
	overUNV -> deactivate
	over?	-> deactivate
	overMark-> deactivate
	overREV ->
		if (nummarks == minefieldcount) 
			apply
		else 
			deactivate

sLbRbDOnlyRight(LbDown)->sLbRbD
	for_each_around(as is now)
sLbRbDOnlyRight(RbDown)->	-> NoAction
sLbRbDOnlyRight(MMove)->		-> NoAction
sLbRbDOnlyRight(LbUp)->		-> NoAction
sLbRbDOnlyRight(RbUp)->sWait

sLbRbDOnlyLeft(LbDown)->	-> NoAction
sLbRbDOnlyLeft(RbDown)->sLbRbD
	for_each_around(as is now)
sLbRbDOnlyLeft(MMove)->		-> NoAction
sLbRbDOnlyLeft(LbUp)->sWait
sLbRbDOnlyLeft(RbUp)->		-> NoAction
