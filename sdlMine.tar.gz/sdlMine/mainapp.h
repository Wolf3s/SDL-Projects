#ifndef __MAIN_APP_H__
#define __MAIN_APP_H__

// forwar refrences to variouts classes used in the app
class BMPCounterButton;
class BMPButton;
class Desktop;
class Grid;

// inherit from the SDLApp
class MySDLApp : public SDLApp
{
public:
	char* pRunningPath;
	// the left 3 digits control - mine couter
	BMPCounterButton* left;
	// the right 3 digits control - time counter
	BMPCounterButton* right;
	// the smile face at center of the top part
	// if it is pressed - new game begins 
	// also it represent various states of the game
	// e.g success, fail on the game over sdtate
	// ot in query hit minefiled  
	BMPButton* smile;
	// the main desktop -> just fill the background 
	Desktop* desktop;
	// the main minefield grid -> that is the game interpreter
	Grid* pGrid;
	// images used in the game
	// digits holder
	CBMPFile fileNums;
	// minefield pictures
	CBMPFile fileDigits;
	// the face at the center
	CBMPFile fileSmiley;

	// the dc fro the control
	PDC* pdc;

	// timer id
	SDL_TimerID m_TimerID;

	// constructor
	MySDLApp();
	// destructor
	~MySDLApp();
	// override the initInstance
	virtual bool initInstance();
	// handle the events 
	virtual void routeEvent(SDL_Event* event);
	// onClick handler
	virtual void onClick(CScreenControl*);
	// the timer events
	virtual Uint32 onTimer(Uint32 interval, void *param);
	// the user events
	virtual Uint32 onUserEvent(SDL_UserEvent* pEvent);
};

#endif //__MAIN_APP_H__